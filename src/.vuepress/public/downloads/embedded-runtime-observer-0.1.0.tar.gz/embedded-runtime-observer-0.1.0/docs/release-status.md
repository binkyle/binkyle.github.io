# v0.1.0 distribution status

- Local repository: implemented, tested, and committed in logical stages.
- Planned public repository: `binkyle/embedded-runtime-observer`.
- A lookup returned 404 and the active GitHub connection exposes no repository-creation action.
  The standalone public repository is **not created or pushed** by this release task.
- The task authorizes distribution through `binkyle/binkyle.github.io`. A source archive and
  three-part article series are prepared for that existing repository; website/CI verification
  results belong to the delivery report. A prepared archive alone is not a deployment result.
- No real business repository was accessed, changed, or included in the release.

## Finish standalone publication

The delivery bundle preserves local history. On a machine with an authenticated GitHub CLI:

```sh
git clone embedded-runtime-observer-history.bundle embedded-runtime-observer
cd embedded-runtime-observer
gh repo create binkyle/embedded-runtime-observer --public --source=. --remote=origin --push
```

First verify that the repository is still absent. If it now exists, inspect its history and merge
the changes instead of recreating/overwriting it. Check the workflow and README commands on GitHub,
then update the article's source-download section with the actual public repository URL. These
commands are remaining steps, not operations claimed to have run here.
